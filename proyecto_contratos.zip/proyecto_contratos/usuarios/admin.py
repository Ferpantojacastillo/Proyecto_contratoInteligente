from django.contrib import admin, messages
from django.contrib.auth.admin import UserAdmin
from django import forms
from django.utils.crypto import get_random_string
from django.core.mail import send_mail
from django.conf import settings
from .models import Usuario


class UsuarioAdminForm(forms.ModelForm):
	docente_password_plain = forms.CharField(
		label='Contraseña docente (asignar)',
		required=False,
		widget=forms.PasswordInput(render_value=False),
		help_text='Asignar contraseña para el portal docente (se guardará hasheada).'
	)

	generar_docente_password = forms.BooleanField(
		label='Generar contraseña docente automáticamente',
		required=False,
		help_text='Marcar para que el sistema genere una contraseña segura al guardar.'
	)

	class Meta:
		model = Usuario
		fields = '__all__'

	def save(self, commit=True):
		user = super().save(commit=False)
		pwd = self.cleaned_data.get('docente_password_plain')
		if pwd:
			user.set_docente_password(pwd)
		# Note: if generar_docente_password is checked we handle generation in ModelAdmin.save_model
		if commit:
			user.save()
		return user


@admin.register(Usuario)
class CustomUserAdmin(UserAdmin):
	form = UsuarioAdminForm
	list_display = ('username', 'email', 'numero_control', 'es_admin_creditos', 'es_docente', 'es_alumno', 'is_staff')
	list_filter = ('es_admin_creditos', 'es_docente', 'es_alumno', 'is_staff')
	fieldsets = UserAdmin.fieldsets + (
		('Información adicional', {'fields': ('numero_control', 'es_admin_creditos', 'es_docente', 'es_alumno', 'docente_password_plain', 'generar_docente_password')}),
	)
	add_fieldsets = UserAdmin.add_fieldsets + (
		('Información adicional', {'fields': ('numero_control', 'es_admin_creditos', 'es_docente', 'es_alumno', 'docente_password_plain', 'generar_docente_password')}),
	)

	def save_model(self, request, obj, form, change):
		# If admin requested generation of a docente password, generate it now and show message
		generar = form.cleaned_data.get('generar_docente_password') if hasattr(form, 'cleaned_data') else False
		generated_pwd = None
		if generar and getattr(obj, 'es_docente', False):
			# generate a reasonably strong password
			generated_pwd = get_random_string(12)
			obj.set_docente_password(generated_pwd)
		super().save_model(request, obj, form, change)
		if generated_pwd:
			# show message to admin
			messages.success(request, f'Contraseña docente generada: {generated_pwd} (cópiala ahora, se muestra sólo una vez).')
			# attempt to send email to docente if email is present
			if getattr(obj, 'email', None):
				subject = 'Credenciales portal docente'
				login_url = getattr(settings, 'SITE_URL', '') + '/creditos/docente/login/' if getattr(settings, 'SITE_URL', None) else '/creditos/docente/login/'
				message = (f'Hola {obj.username},\n\n' 
				           f'Se ha creado/actualizado tu acceso al portal de docentes.\n' 
				           f'Usuario: {obj.username}\n' 
				           f'Contraseña docente: {generated_pwd}\n\n' 
				           f'Accede aquí: {login_url}\n\n' 
				           'Por seguridad, esta contraseña sólo se muestra una vez; si la pierdes, pide al administrador que la regenere.')
				from_email = getattr(settings, 'DEFAULT_FROM_EMAIL', None)
				try:
					send_mail(subject, message, from_email, [obj.email], fail_silently=False)
					messages.info(request, f'Se envió la contraseña por correo a {obj.email}.')
				except Exception as e:
					messages.error(request, f'No se pudo enviar el correo a {obj.email}: {e}')
